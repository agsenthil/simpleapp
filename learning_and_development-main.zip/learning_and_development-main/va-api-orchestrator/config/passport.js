/**
 * This module defines the SAML strategy and retrieves the user profile from SAML Assertion
 */


const SamlStrategy = require('passport-saml').Strategy;
const userDataRetriever = require('../controllers/userDataRetriever');

module.exports = function (passport, config) {
    console.log('saml strategy function called');

    passport.serializeUser(function (user, done) {
        console.log('serializeUser called:', JSON.stringify(user));
        done(null, user);
    });

    passport.deserializeUser(function (user, done) {
        console.log("DeSerializer called:",user);
        done(null, user);
    });

    passport.use(new SamlStrategy(
        config.passport.saml,
        function (profile, done) {
            console.log('The profile is ', profile);
            return done(null, {
                bemsId: profile.nameID,
                sAMAccountName: profile.sAMAccountName

            });
        }));
};