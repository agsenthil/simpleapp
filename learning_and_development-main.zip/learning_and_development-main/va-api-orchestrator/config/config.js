/**
 * Defines the Configuration for SAML based SSO Integration. The properties need to be externalized to OCP's Config Map
 */

module.exports = {
    development: {
      app: {
        name: 'Virtual Assistant API Orchestrator',
        port: process.env.PORT || 3000
      },
      passport: {
        strategy: 'saml',
        saml: {
          callbackUrl: process.env.SSO_CALLBACK_URL || 'https://api-virtual-assistant-poc.apps.cp4d-pre-phx.k8s.boeing.com/auth/login/sso/callback',
          entryPoint: process.env.SSO_ENTRYPOINT || 'https://securelogon-preprod.boeing.com/PSAML/idp/startSSO.ping?PartnerSpId=VirtualAssistantPoC',
          issuer: process.env.SSO_ISSUER || 'VirtualAssistantPoC',
          cert: process.env.SSO_CERT || null,
          path: '/auth/login/sso/callback'
        }
      }
    }
  };