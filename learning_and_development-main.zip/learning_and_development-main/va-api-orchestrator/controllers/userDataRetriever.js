const ldap = require('ldapjs');


const userName = process.env.LDAP_USER;
const password = process.env.LDAP_PASSWORD;

const client = ldap.createClient({
    url: 'ldap://nos.boeing.com:389',
    reconnect: true,
    timeout: 5000,
});


const userSearchBase = 'ou=End Users, ou=Accounts, dc=nos, dc=boeing, dc=com';
const UserDataRetriever = {
    retrieveData: (employeeNumber) => {
        return new Promise((resolve, reject) => {


            var opts = {
                filter: '(&(objectclass=user)(employeeNumber=' + employeeNumber + '))',
                scope: 'sub',
                attributes: ['employeeNumber', 'cn', 'mail']
            };

            console.log('--- going to try to connect user ---');
            client.on('error',(err)=>{
                console.log("Error from ldap handler:",err.code);
            })

            client.bind(userName, password, function (error, user) {
                if (error) {
                    console.log("Error in connecting to LDAP Server :", error);
                    reject(error);
                    return;
                }
                console.log('Connected successfully to LDAP server');

                client.search(userSearchBase, opts, function (error, search) {
                    if (error) {
                        console.log("Error in searching the bemsid, " + employeeNumber + " in LDAP Directory");
                        reject(error);
                        return;
                    }
                    search.on('searchEntry', function (entry) {
                        console.log("User Info Found:" + JSON.stringify(entry.object));
                        user = {
                            name: entry.object.cn,
                            emailAddress: entry.object.mail,
                            bemsid: entry.object.employeeNumber
                        };
                        resolve(user);

                    });
                    search.on('searchReference', function (referral) {
                        console.log('referral: ' + referral.uris.join());
                    });
                    search.on('error', function (err) {
                        console.error('error: ' + err.message);
                    });
                    search.on('end', function (result) {
                        console.log('status: ' + result);

                    });


                });

            });

        });
    },

    closeDataRetriever: () => {

        return new Promise((resolve) => {
            client.unbind();
            client.destroy();
            resolve(console.log("Client unbound successfully"));
        });
    }

}
module.exports = UserDataRetriever;