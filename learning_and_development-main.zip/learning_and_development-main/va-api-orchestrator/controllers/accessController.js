const accessController = {
    access: (userInfo, req, res) => {
        try {
            if (userInfo[req.body.BEMSID]) {
                const jsonUpdated = userInfo[req.body.BEMSID];
                delete jsonUpdated["emailPassword"];
                res.json({ response: userInfo[req.body.BEMSID] });
            } else {
                //if BEMSID is not found in list return invalid response
                res.json({ response: "Invalid" });
            }
        } catch (err) {
        console.log(err);
        }
}
};

module.exports = accessController;