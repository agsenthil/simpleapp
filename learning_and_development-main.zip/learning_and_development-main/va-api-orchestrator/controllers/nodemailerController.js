const nodemailer = require("nodemailer");

var nodemailerController = {
  mailer: (email, req, res) => {
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT),
      ignoreTLS: true,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASSWORD,
      },
    });

    const sendEmail = (options) => {
      const { mail_type, text } = options; 
      console.log(`User Email: ${email}\nMail Type: ${mail_type}\nText: ${text}`);       

      if (!email || !mail_type || !text) {
        console.log("Missing required email values");
        return res.json({ response: "Invalid", code: 400 });
      }
      console.log("Sending Email");
      try {
        return transporter.sendMail(
          {
            from: `${process.env.FROM_NAME} <${process.env.FROM_EMAIL}>`,
            to: process.env.SUPPORT_EMAIL,
            bcc: process.env.FROM_EMAIL,
            cc: process.env.DEV_EMAIL_LIST,
            subject: `Support Issue: ${mail_type}`,
            html: text,
          },
          (error, info) => {
            if (error) {
              res.json({ response: "Invalid", code: 400 });
              return console.log(error);
            }
            console.log("Message sent: %s", info);
            res.json({ response: "Email Sent Successfully", code: 200 });
          }
        );
      } catch (e) {
        console.log("Error in sending email dure to ",e);
        throw Error(`Error sending email`);
      }
    };
    console.log(sendEmail(req.body));
  },
};

module.exports = nodemailerController;
