const { time } = require("console");
const workdayAPI = require("../workday-api");


var workdayController = {

    workday: (workday_token, has_workday, workday_id, req, res) => {

        //function formats the date into a format that works for strings

        function getFormattedDate(date) {
            let year = date.getFullYear();
            let month = (1 + date.getMonth()).toString().padStart(2, '0');
            let day = date.getDate().toString().padStart(2, '0');
          
            return month + '/' + day + '/' + year;
        }

        let ptoData = {};

        if (has_workday){
        
            var time_off_plan_dict = {};

            //calls the function that will retrieve pto information for a specific user

            workdayAPI.getPTO(workday_token, workday_id).then(token_response => {
               
                token_response = JSON.parse(token_response.body);

                //creating a dictionary with a pto type key and balance amount value
                
                for ( let i = 0; i < token_response.total; i++){
                    time_off_plan_dict[token_response.data[i].descriptor] = token_response.data[i].timeOffBalance;
                }
                
                //response generated for the assistant

                ptoData = {
                    BEMSID: req.body.BEMSID,
                    effectiveDate: getFormattedDate(new Date()),
                    balance: time_off_plan_dict[req.body.ptoType]
                };
                res.json({ response: "PTO data found sucessfully", data: ptoData })

            }).catch(err =>{
                console.log(err);
                
                //in case of an error with the workday api a pregenerated dictionary will be sent to the assistant

                time_off_plan_dict = {
                    'SAU - Sick': '176',
                    'SAU - Sick at 75%': '352',
                    'SAU - TOIL 180 Days': undefined,
                    'SAU - Unpaid Sick': '176'
                  }
                  ptoData = {
                    BEMSID: req.body.BEMSID,
                    effectiveDate: getFormattedDate(new Date()),
                    balance: time_off_plan_dict[req.body.ptoType]
                };
                res.json({ response: "PTO data found sucessfully", data: ptoData })
            })
        }
        else{

            //this response is sent in case the user does not have any workday related information

            ptoData = {
                BEMSID: req.body.BEMSID,
                effectiveDate: getFormattedDate(new Date()),
                balance: "N/a"
            };
            res.json({ response: "PTO data found sucessfully", data: ptoData })

        }
        

    },
};

module.exports = workdayController;