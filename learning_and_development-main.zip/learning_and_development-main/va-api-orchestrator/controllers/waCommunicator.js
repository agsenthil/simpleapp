
/**
 * Propagates the SSO user data to Watson Assistant's Context variables to be used in the Dialog flows.
 */

const AssistantV2 = require('ibm-watson/assistant/v2');
const { BearerTokenAuthenticator } = require('ibm-watson/auth');

const assistant = new AssistantV2({
    version: '2020-04-01',
    authenticator: new BearerTokenAuthenticator({
        bearerToken: "<Needs to be retrieved either from Vault or from OCP's Config Secret>"

    }),
    //Hard-code URL needs to be moved to a Config Map 
    serviceUrl: 'https://cpd-cp4dpre.apps.cp4d-pre-phx.k8s.boeing.com/assistant/cp4dpre-wa/instances/1651527368321421/api',
    disableSslVerification: true
});

const assistantId = '20cb4154-01b8-4881-871c-8774f4927be0';
var sessionId = '';

const waCommunicator = {
    setUserData: (userData) => {
        assistant.createSession({
            assistantId
        })
            .then(res => {
                // console.log("SessionId:", JSON.stringify(res.result, null, 2));
                sessionId = res.result
                // console.log("Sess Id->", sessionId.session_id);
                assistant.message({
                    assistantId: assistantId,
                    sessionId: sessionId.session_id,
                    input: {
                        'message_type': 'text',
                        'text': 'Hello'
                    },
                    context: {
                        'global': {
                            'system': {
                                'user_id': userData.name
                            }
                        },
                        'skills': {
                            'main skill': {
                              'user_defined': {
                                'user': userData
                              }
                            }
                          }
                    }
                })
                .then(res => {
                     console.log(JSON.stringify(res, null, 2));
                  })


            }).catch(err => {
                console.log(err);
            });

        // console.log("SessionId:", sessionId);


        // get cookie



    }
}

module.exports = waCommunicator;