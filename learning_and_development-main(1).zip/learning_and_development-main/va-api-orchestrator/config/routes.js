const userDataRetriever = require('../controllers/userDataRetriever');

module.exports = function (app, config, passport) {
    console.log('Route loaded');
    // GET route that handles LDAP callback if not redirects to /login route
    app.get('/', function (req, res) {
        

        if (req.isAuthenticated()) {
            console.log("Call LDAP");
        } else {
            console.log("User is not authenticated. Redirecting to /login");
            res.redirect('/login');
        }
    });

    // GET route to use passport middleware authenticator
    app.get('/login',
        passport.authenticate(config.passport.strategy, {
            successRedirect: '/',
            failureRedirect: '/login'
        }, function (req, res) {

            res.redirect('/');
        })
    );
    
    // POST method for saml authentication
    app.post(config.passport.saml.path,
        passport.authenticate(config.passport.strategy,
            {
                failureRedirect: '/',
                failureFlash: true
            }),
        // function that pulls user bemsID and saves it into a cookie BOEING_VA_USER
        function ( req, res) {
            console.log("Callback invoked. Redirecting to root(/)");
            let user = req.user;
            
            userDataRetriever.retrieveData(user.bemsId)
                .then(userData => {
                    res.cookie("BOEING_VA_USER", userData,{httpOnly:true});
                    waCommunicator.setUserData(userData);
                  
                }).then(()=>{
                    userDataRetriever.closeDataRetriever();
                })
                .then(()=>res.redirect('/'))
                .catch(err => console.error(err));
           
            ;
        }
    );

}