const express = require("express");
const path = require('path');

// SSO Integration Modules start here
const passport = require('passport');
const session = require('express-session');
cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
//SSO Integration Modules end here

const dotenv = require("dotenv");

//workday token and pto dictionary gathering
const workdayAPI = require("./workday-api");


//for production deployment
const https = require("https");

// for local testing
const http = require("http");
dotenv.config();

const nodemailerController = require("./controllers/nodemailerController");
const workdayController = require("./controllers/workdayController");
const accessController = require("./controllers/accessController");


var env = process.env.NODE_ENV || 'development';
const config = require('./config/config')[env];
const { time } = require("console");
const { func } = require("assert-plus");


//Load the Config 
require('./config/passport')(passport, config);

var app = express();


//SSO related starts here
app.set('port', config.app.port);
app.use(cookieParser());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(session(
  {
    resave: true,
    saveUninitialized: true,
    secret: 'secret'
  }));
app.use(passport.initialize());
app.use(passport.session());
app.use(express.static(path.join(__dirname, 'public')));
app.use("/ready", (request, response) => {
  return response.sendStatus(200);
});

app.use("/live", (request, response) => {
  
  return response.sendStatus(200);
});

require('./config/routes')(app, config, passport);

var userInfo = JSON.parse(retrieveConfigMap());


//collect the workday bearer token as soon as the service is started

var workday_token = ''
workdayAPI.getToken().then(data => {
  console.log("Workday Token collected");
  workday_token = data});

//refresh the user information every 2 seconds

setInterval(() => {
  userInfo = JSON.parse(retrieveConfigMap());
}, Number(process.env.INTERVAL));


//refresh workday bearer token every hour
setInterval(() => {
  workday_token = workdayAPI.getToken().then(data => {
    console.log("Workday Token refreshed")
    workday_token = data});
}, Number(process.env.WORKDAY_INTERVAL));


app.post("*", function (req, res) {
  
  if (req.body.type === "access") {
    // send user information to watson assistant
    console.log("Access request at", new Date());
    accessController.access(userInfo, req, res);
  }
  if (req.body.type === "mailer") {
    // send mail on behalf of watson assistant and return fail/success
    console.log("Mail request at", new Date());
    nodemailerController.mailer(userInfo[req.body.BEMSID]["emailAddress"], req, res);
  }
  if (req.body.type === "workday") {
    // retrieve workday out of office time and return a dictionary of result to the assistant
    console.log("Workday request at", new Date());
    if (req.body.BEMSID === null) {
      console.log("BEMSID not found in request body");
      return;
    }

    // determine if a user has wokrday access
    var workday_id = userInfo[req.body.BEMSID]["workdayID"];

    var has_workday = false;
    if (workday_id){
      has_workday = true;
    }
    workdayController.workday(workday_token, has_workday, workday_id, req, res);
  };
});

function retrieveConfigMap() {
  return process.env.CONFIG_MAP;
}

function retrieveTLSCert() {
  return process.env.TLS_CERT;
}

function retrieveTLSPrivateKey() {
  return process.env.TLS_KEY;
}

const options = {
  key: retrieveTLSPrivateKey(),
  cert: retrieveTLSCert(),
};

//for production deployment
https.createServer(options, app).listen(app.get('port'), function (req, res) {
  console.log(`Server started at port ${process.env.PORT}`);
});

//for local testing
//  const server = http.createServer(app).listen(8080, function (req, res) {
 
//    console.log(`Server started at port 8080`);
//  });