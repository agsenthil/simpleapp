// api call to get the workday bearer token

var request = require('request');

async function getToken(){
  var options = {
    'method': 'POST',
    'url': 'https://wd2-impl-services1.workday.com/ccx/oauth2/boeing1/token',
    'proxy':'http://www-proxy-us.boeing.com:31060',
    'headers': {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': 'Basic WmpsaFlXWmhNbVl0TWpWaU1DMDBZVGRoTFRnME56TXROemxrTlRoak5UY3lZVFEyOmFtOGkydWZsenp5ODk3YXRpbjZ6OThhZDdjZ3pseXdicTBwY2xmdmpjbzFnbDM1NmJhbm9kb3YycHlxcnhjMnRtMTUzNG5yN3FrbTBpM2UybmhuajBkcGZvaXY0YmIyZDF1ag=='
    },
    body: 'grant_type=refresh_token&refresh_token=7q7qsyyrb2e3a13tnarnscfmcdsvk5vbh8wq1lsgyjbfhkg2ekntiisox20pyyebpc7xmix3brkwjxkybj2dz30mua44hb8h2v7'

  };
  return new Promise((resolve, reject) => {
    request(options, function (error, response) {
      if (error){
        console.log("Error on token retrieval")
        throw new Error(error);
        reject("N/a");
      };
      resolve( JSON.parse(response.body)["access_token"] );
     
    });
  });  
}

// api call to workday to retrieve user specific pto information

async function getPTO( workday_bearer_token, integration_id = 'f5cb4ef66dbd010d2fa5cb77e300caf1'){
  
  if (workday_bearer_token === "FAIL"){
    return {
      'SAU - Sick': '176',
      'SAU - Sick at 75%': '352',
      'SAU - TOIL 180 Days': undefined,
      'SAU - Unpaid Sick': '176'
    };
  }
  var options = {
    'method': 'GET',
    'url': 'https://wd2-impl-services1.workday.com/ccx/api/common/v1/boeing1/workers/'+ integration_id +'/timeOffPlans',
    'proxy':'http://www-proxy-us.boeing.com:31060',
    'headers': {
      'Authorization': 'Bearer '.concat(workday_bearer_token),
      'Content-Type': 'application/json'
    }
  };
  return new Promise((resolve, reject) => {
     request(options, function (error, response) {
      if (error){ 
        resolve({
          'SAU - Sick': '176',
          'SAU - Sick at 75%': '352',
          'SAU - TOIL 180 Days': undefined,
          'SAU - Unpaid Sick': '176'
        })
        throw new Error(error);
      }
      resolve(response)
    });
  });
}

module.exports = { getPTO, getToken };
