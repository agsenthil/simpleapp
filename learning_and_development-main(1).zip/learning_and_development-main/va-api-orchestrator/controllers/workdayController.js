const { time } = require("console");
const workdayAPI = require("../workday-api");


var workdayController = {

    workday: (workday_token, has_workday, workday_id, req, res) => {

        //function formats the date into a format that works for strings

        function getFormattedDate(date) {
            let year = date.getFullYear();
            let month = (1 + date.getMonth()).toString().padStart(2, '0');
            let day = date.getDate().toString().padStart(2, '0');
          
            return month + '/' + day + '/' + year;
        }

        let ptoData = {};

        if (has_workday){
        
            var time_off_plan_dict = {};

            //calls the function that will retrieve pto information for a specific user

            workdayAPI.getPTO(workday_token, workday_id).then(token_response => {
               
                token_response = JSON.parse(token_response.body);

                //creating a dictionary with a pto type key and balance amount value


                /* initially this loop was used to create the response dictionary however the key name must 
                    be without spaces and special characters to be used for the context variables
                for ( let i = 0; i < token_response.total; i++){
                    time_off_plan_dict[token_response.data[i].descriptor] = token_response.data[i].timeOffBalance;
                }*/

                // using the indexed values and custom key names to satisfy the context variable requirements on the side of the watson assistant

                time_off_plan_dict = {
                    'Sick':token_response.data[0].timeOffBalance,
                    'Sickat75':token_response.data[1].timeOffBalance,
                    'UnpaidSick':token_response.data[3].timeOffBalance,
                }
                
                //response data for the assistant

                ptoData = {
                    BEMSID: req.body.BEMSID,
                    effectiveDate: getFormattedDate(new Date()),
                    balance: time_off_plan_dict
                };
            }).catch(err =>{
                console.log(err);
                
                //in case of an error with the workday api an error string is sent
                ptoData = {
                    BEMSID: req.body.BEMSID,
                    effectiveDate: getFormattedDate(new Date()),
                    balance: "workday error"
                };
            }).then(() => {
                res.json({ response: "PTO data found sucessfully", data: ptoData })
            })
        }
        else{

            //this response is sent in case the user does not have any workday related information

            ptoData = {
                BEMSID: req.body.BEMSID,
                effectiveDate: getFormattedDate(new Date()),
                balance: "N/a"
            };
            res.json({ response: "PTO data found sucessfully", data: ptoData })

        }
        

    },
};

module.exports = workdayController;